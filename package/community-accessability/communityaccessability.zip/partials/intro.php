<?php
  /** Template to display intro section */
?>
<section class="section--full section--grey">
  <article class="content content--center content--feature">
    <?php the_sub_field('intro'); ?>
  </article>
</section>
